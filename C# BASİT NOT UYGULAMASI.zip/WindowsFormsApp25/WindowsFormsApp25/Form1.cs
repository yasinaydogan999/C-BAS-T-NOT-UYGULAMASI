﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp25
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double not1, not2, proje, oprt;
            string durum;
            not1 = Convert.ToDouble(textBox1.Text);
            not2 = Convert.ToDouble(textBox2.Text);
            proje = Convert.ToDouble(textBox3.Text);

            oprt = (not1 + not2 + proje) / 3;

            if (oprt >=  50)
            {
                durum = "Geçti";
            }
            else
            {
                durum = "kaldı";
            }
            textBox4.Text = oprt.ToString("0.00") + "/" + durum;
        }
    }
}
